package itec625methodsWorkshop;

public class AllInOne {
	/**
	 * 
	 * @param a
	 * @param b
	 * @return smaller of the two values
	 */
	public static int smaller(int a, int b) {
		if(a < b)
			return a;
		else
			return b;
	}

	/**
	 * 
	 * @param a
	 * @param b
	 * @return true if both a and b are even 
	 * or both a and b are odd, false in all other cases
	 */
	public static boolean sameOddity(int a, int b) {
		return (a-b)%2 == 0;
	}

	/**
	 * 
	 * @param n (assume n > 0)
	 * @return sum of the first n positive integers.
	 * for example,
	 * if n = 4, return 10 (1+2+3+4)
	 * if n = 6, return 21 (1+2+3+4+5+6)
	 * 
	 * you should do this using a loop and NOT use
	 * the gaussian formula sum(n) = n*(n+1)/2
	 */
	public static int sum(int n) {
		int result = 0;
		for(int i=1; i <= n; i++) {
			result = result + i;
		}
		return result;
	}

	/**
	 * 
	 * @param n (assumed to be non-negative)
	 * @return highest digit in the number. 
	 * for example,
	 * if n = 18293, return 9
	 * if n = 45123, return 5
	 * if n = 10, return 1
	 * if n = 0, return 0
	 */
	public static int maxDigit(int n) {
		int result = 0;
		while(n!=0) {
			if(n%10 > result) {
				result = n%10;
			}
			n=n/10;
		}
		return result;
	}
	
	/**
	 * 
	 * @param n assumed to be more than 0
	 * @param loc assumed to be between 0 and (number of digits in n - 1)
	 * @return digit at that location
	 * for example, 
	 * if n = 1729, loc = 0, return 9
	 * if n = 1729, loc = 1, return 2
	 * if n = 1729, loc = 2, return 7
	 * if n = 1729, loc = 3, return 1
	 * 
	 * if n = 508832, loc = 4, return 0
	 */
	public static int getDigit(int n, int loc) {
		for(int i=0; i < loc; i++) {
			n/=10;
		}
		return n%10;
	}

	/**
	 * DO NOT MODIFY THIS METHOD
	 * It acts as a helper to displayPrimes
	 * @param n
	 * @return true if n is a prime number, false otherwise
	 */
	public static boolean isPrime(int n) {
		if(n < 2)
			return false;
		for(int i=2; i*i <= n; i++) {
			if(n%i == 0) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @param a
	 * @param b
	 * @return product of all primes in range [a, b]
	 * 
	 * for example, if a = 6 and b = 19, return
	 * 7*11*13*17*19 = 323323
	 * 
	 * Tip: call method isPrime
	 */
	public static int primeProduct(int a, int b) {
		int result = 1;
		for(int i=a; i<=b; i++) {
			if(isPrime(i)) {
				result = result * i;
			}
		}
		return result;
	}

	/**
	 * CHALLENGING
	 * @param a (assume it's non-negative)
	 * @param b (assume it's non-negative) 
	 * @param start (assume in range [1, 8])
	 * @param end (assume more than or equal to start and in range [1, 8])
	 * @return result of applying a bitwise and 
	 * on a and b in the bit range start to end 
	 * for example,
	 * a = 119 (00000000000000000000000001110111)
	 * b = 95  (00000000000000000000000001011111)
	 * start = 2
	 * end = 5
	 * 
	 * a = 000000000000000000000000 01   1101   11
	 * b = 000000000000000000000000 01   0111   11
	 *                                   &&&&  
	 * c = 000000000000000000000000 00   0101   00
	 * 
	 * return 00000000000000000000000000010100 = 20
	 */
	public static int andSelectedBits(int a, int b, int start, int end) {
		//System.out.println(Integer.toBinaryString(a));
		//System.out.println(Integer.toBinaryString(b));
		a = a >>> (7-end) << (7-end) << 24 + start >>> 24 + start;
		b = b >>> (7-end) << (7-end) << 24 + start >>> 24 + start;
		//System.out.println(Integer.toBinaryString(a));
		//System.out.println(Integer.toBinaryString(b));
		return a & b;
	}
}
