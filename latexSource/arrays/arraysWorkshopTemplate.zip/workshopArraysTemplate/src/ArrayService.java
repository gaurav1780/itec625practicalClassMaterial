public class ArrayService {
	/**
	 * @param arr
	 * @param min
	 * @param max: assume max >= min
	 * @return true if there is any value in array arr that lies
	 * in the range [min, max], false otherwise
	 * for example,
	 * if arr = {10, 70, 20, 90}, min = 30, max = 70, return true
	 * if arr = {10, 70, 20, 90}, min = 30, max = 60, return false
	 */
	public static boolean contains(int[] arr, int min, int max) {
		return false; //to be completed
	}

	/**
	 * @param a
	 * @param b
	 * @return true if a and b are identical, false otherwise
	 * for example,
	 * if a = {10, 70, 20}, b = {10, 70, 20}, return true
	 * if a = {10, 70, 20}, b = {10, 70, 20, 90}, return false
	 * if a = {10, 70, 20, 90}, b = {10, 70, 20}, return false
	 * if a = {10, 70, 20}, b = {10, 70, 30}, return false
	 * if a = {10, 70, 20}, b = {30, 70, 20}, return false
	 */
	public static boolean areIdentical(int[] a, int[] b) {
		return false; //to be completed
	}
	
	public static int[] getPositiveItems(int[] a) {
		return null; //to be completed
	}
	
	/**
	 * CHALLENGING
	 * @param a assume that a doesn't contain any item more than once
	 * @param b assume that b doesn't contain any item more than once
	 * @return array containing items in both a and b, in the order they appear in a
	 * see tests for examples
	 */
	public static int[] intersection(int[] a, int[] b) {
		return null; //to be completed
	}
	
	/**
	 * CHALLENGING
	 * @param arr
	 * @return an array containing the longest streak of ascending items in arra.
	 * see test for examples
	 */
	public static int[] getLongestAscendingStreak(int[] arr) {
		return null; //to be completed
	}
}