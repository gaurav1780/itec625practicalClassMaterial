import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayServiceTest {

	@Test
	public void testContains() {
		int[] a = {20, -50, 30, -40, 90};
		assertTrue(ArrayService.contains(a, 10, 20));
		assertTrue(ArrayService.contains(a, 30, 50));
		assertTrue(ArrayService.contains(a, -60, -20));
		assertTrue(ArrayService.contains(a, -50, -45));
		assertTrue(ArrayService.contains(a, -45, -40));

		assertFalse(ArrayService.contains(a, -49, -41));
		assertFalse(ArrayService.contains(a, 31, 89));
		assertFalse(ArrayService.contains(a, -39, 19));
	}

	@Test
	public void testAreIdentical() {
		int[] a = {20, -50, 30};
		int[] b = {20, -50, 30};
		assertTrue(ArrayService.areIdentical(a, b));

		int[] c = {20, -50, 30};
		int[] d = {20, -50, 30, 60};
		assertFalse(ArrayService.areIdentical(c, d));

		int[] e = {20, -50, 30, 60};
		int[] f = {20, -50, 30};
		assertFalse(ArrayService.areIdentical(e, f));

		int[] g = {20, -50, 30};
		int[] h = {20, -50, 40};
		assertFalse(ArrayService.areIdentical(g, h));

		int[] i = {20, -50, 30};
		int[] j = {10, -50, 30};
		assertFalse(ArrayService.areIdentical(i, j));
	}
	
	@Test
	public void testGetPositiveItems() {
		assertArrayEquals(new int[] {5,1,3}, ArrayService.getPositiveItems(new int[]{-6, 0, 5, -2, -9, 1, 0, 0, 3}));
		assertArrayEquals(new int[] {}, ArrayService.getPositiveItems(new int[]{-6, 0, -2, -9, 0, 0}));
	}
	
	@Test
	public void testIntersection() {
			assertArrayEquals(new int[] {5,1,3}, ArrayService.intersection(new int[]{5,1,2,4,3}, new int[] {3,5,7,8,9,1}));
			assertArrayEquals(new int[] {}, ArrayService.intersection(new int[]{2,4}, new int[] {3,5,7,8,9,1}));
	}
	
	@Test
	public void testGetLongestAscendingStreak() {
			assertArrayEquals(new int[] {-9,1,2,6,6,12}, ArrayService.getLongestAscendingStreak(new int[]{-6, 0, 5, -2, -9, 1, 2, 6, 6, 12,4,8,10,12}));
			assertArrayEquals(new int[] {6}, ArrayService.getLongestAscendingStreak(new int[]{6,0,-6}));
	}
}