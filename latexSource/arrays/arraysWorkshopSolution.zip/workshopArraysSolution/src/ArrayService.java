public class ArrayService {
	/**
	 * @param arr
	 * @param min
	 * @param max: assume max >= min
	 * @return true if there is any value in array arr that lies
	 * in the range [min, max], false otherwise
	 * for example,
	 * if arr = {10, 70, 20, 90}, min = 30, max = 70, return true
	 * if arr = {10, 70, 20, 90}, min = 30, max = 60, return false
	 */
	public static boolean contains(int[] arr, int min, int max) {
		if(arr == null)
			return false;
		for(int i=0; i < arr.length; i++) {
			if(arr[i] >= min && arr[i] <= max) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param a
	 * @param b
	 * @return true if a and b are identical, false otherwise
	 * for example,
	 * if a = {10, 70, 20}, b = {10, 70, 20}, return true
	 * if a = {10, 70, 20}, b = {10, 70, 20, 90}, return false
	 * if a = {10, 70, 20, 90}, b = {10, 70, 20}, return false
	 * if a = {10, 70, 20}, b = {10, 70, 30}, return false
	 * if a = {10, 70, 20}, b = {30, 70, 20}, return false
	 */
	public static boolean areIdentical(int[] a, int[] b) {
		if(a==null || b==null)
			return false;
		if(a.length != b.length)
			return false;
		for(int i=0; i < a.length; i++) {
			if(a[i] != b[i]) {
				return false;
			}
		}
		return true;
	}
	
	public static int[] getPositiveItems(int[] a) {
		if(a==null)
			return null;
		int count = 0;
		for(int i=0; i < a.length; i++) {
			if(a[i] > 0) {
				count++;
			}
		}
		int[] result = new int[count];
		int destIndex = 0;
		for(int i=0; i < a.length; i++) {
			if(a[i] > 0) {
				result[destIndex] = a[i];
				destIndex++;
			}
		}
		return result;
	}
	
	/**
	 * 
	 * @param a assume that a doesn't contain any item more than once
	 * @param b assume that b doesn't contain any item more than once
	 * @return array containing items in both a and b, in the order they appear in a
	 */
	public static int[] intersection(int[] a, int[] b) {
		int count = 0;
		for(int i=0; i < a.length; i++) {
			int originalCount = count;
			for(int k=0; k < b.length && count == originalCount; k++) {
				if(a[i] == b[k]) {
					count++;
				}
			}
		}
		int[] result = new int[count];
		int destIndex = 0;
		for(int i=0; i < a.length; i++) {
			int originalDestIndex = destIndex;
			for(int k=0; k < b.length && destIndex == originalDestIndex; k++) {
				if(a[i] == b[k]) {
					result[destIndex] = a[i];
					destIndex++;
				}
			}
		}
		return result;
	}
	
	public static int[] getLongestAscendingStreak(int[] arr) {
		int[] lengths = new int[arr.length];
		for(int i=0; i < arr.length; i++) {
			lengths[i] = 1;
			boolean ascending = true;
			for(int k=i+1; k < arr.length && ascending; k++) {
				if(arr[k] >= arr[k-1]) {
					lengths[i]++;
				}
				else {
					ascending = false;
				}
			}
		}
		int max = 0;
		for(int i=1; i < lengths.length; i++) {
			if(lengths[i] > lengths[max]) {
				max = i;
			}
		}
		int[] result = new int[lengths[max]];
		for(int i=0; i < result.length; i++) {
			result[i] = arr[max+i];
		}
		return result;
	}
}