//anything after a double slash is a comment

/*
 * a multi-line comment is between slash star and star slash
 */

public class Program1 {
	public static void main(String[] args) {
		System.out.println("Hallelujah");
	}
}
