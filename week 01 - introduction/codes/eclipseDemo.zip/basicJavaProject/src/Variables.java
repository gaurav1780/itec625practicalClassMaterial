public class Variables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = -12; //whole numbers are stored as int (or long)
		double b = 2.5; //real numbers are stored as double
		boolean c = true; //booleans can either be true (yes) or false (no)
		char d = '$'; //char can hold a single symbol (symbol should be between single quotes)
		String e = "Vendetta"; //text is stored as String
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(a+" "+b+" "+c+" "+d+" "+e); //concatenated output	
	}

}
